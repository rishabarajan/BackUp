package com.hex.hms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hex.hms.dto.PatientReportCountDto;
import com.hex.hms.model.Patient;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Integer> {

//    @Query("SELECT new com.hex.hms.dto.PatientReportCountDto(p.id, p.name, p.city, p.idProof, COUNT(r)) " +
//           "FROM Patient p LEFT JOIN Report r ON p.id = r.patient.id " +
//           "GROUP BY p.id, p.name, p.city, p.idProof")
//    List<PatientReportCountDto> fetchAllPatientsWithReportCount();
}
