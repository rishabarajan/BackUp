package com.hex.hms.enums;

public enum IdProof {
    AADHAR, PAN
}
