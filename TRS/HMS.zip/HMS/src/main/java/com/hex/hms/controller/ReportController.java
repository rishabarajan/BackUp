package com.hex.hms.controller;

import com.hex.hms.model.Report;
import com.hex.hms.service.ReportService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/report")
public class ReportController {
    @Autowired
    private  ReportService reportService;

    @PostMapping("/add/{patientId}")
    public ResponseEntity<Report> addReport(@RequestBody Report report, @PathVariable int patientId) {
        Report saved = reportService.addReport(report, patientId);
        return ResponseEntity.ok(saved);
    }
}
