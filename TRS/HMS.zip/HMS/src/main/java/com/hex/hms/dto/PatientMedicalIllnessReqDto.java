package com.hex.hms.dto;

public class PatientMedicalIllnessReqDto {

}
