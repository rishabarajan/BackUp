package com.hex.hms.dto;

public class PatientReportCountDto {
    private int id;
    private String name;
    private String city;
    private String idProof;
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getIdProof() {
		return idProof;
	}

	public void setIdProof(String idProof) {
		this.idProof = idProof;
	}

	public long getNoOfReports() {
		return noOfReports;
	}

	public void setNoOfReports(long noOfReports) {
		this.noOfReports = noOfReports;
	}

	private long noOfReports;

    public PatientReportCountDto() {
	}

	public PatientReportCountDto(int id, String name, String city, String idProof, long noOfReports) {
		super();
        this.id = id;
        this.name = name;
        this.city = city;
        this.idProof = idProof;
        this.noOfReports = noOfReports;
    }

    
}
