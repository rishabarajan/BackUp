package com.hex.hms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.hex.hms.dto.PatientMedicalIllnessDto;
import com.hex.hms.model.PatientMedicalIllness;
import com.hex.hms.service.PatientMedicalIllnessService;

@RestController
@RequestMapping("/api/pmi")
public class PatientMedicalIllnessController {

    @Autowired
    private PatientMedicalIllnessService service;

    @PostMapping("/add")
    public PatientMedicalIllness addPatientMedicalIllness(@RequestBody PatientMedicalIllnessDto dto) {
        return service.addPatientMedicalIllness(dto);
    }
}
