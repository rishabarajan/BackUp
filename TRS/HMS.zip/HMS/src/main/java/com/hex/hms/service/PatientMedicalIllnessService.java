package com.hex.hms.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hex.hms.model.MedicalIllness;
import com.hex.hms.model.Patient;
import com.hex.hms.model.PatientMedicalIllness;
import com.hex.hms.dto.PatientMedicalIllnessDto;
import com.hex.hms.repository.MedicalIllnessRepository;
import com.hex.hms.repository.PatientMedicalIllnessRepository;
import com.hex.hms.repository.PatientRepository;

@Service
public class PatientMedicalIllnessService {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private MedicalIllnessRepository medicalIllnessRepository;

    @Autowired
    private PatientMedicalIllnessRepository patientMedicalIllnessRepository;

    public PatientMedicalIllness addPatientMedicalIllness(PatientMedicalIllnessDto dto) {
        
        Patient patient = patientRepository.findById(dto.getPatientId())
                .orElseThrow(() -> new RuntimeException("Patient not found"));

      
        MedicalIllness illness = medicalIllnessRepository.findById(dto.getMedicalIllnessId())
                .orElseThrow(() -> new RuntimeException("Medical Illness not found"));

        
        PatientMedicalIllness pmi = new PatientMedicalIllness();
        pmi.setPatient(patient);
        pmi.setMedicalIllness(illness);
        pmi.setSinceWhen(dto.getSinceWhen());

        return patientMedicalIllnessRepository.save(pmi);
    }
}
