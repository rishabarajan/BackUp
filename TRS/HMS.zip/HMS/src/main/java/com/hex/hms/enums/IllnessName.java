package com.hex.hms.enums;

public enum IllnessName {
    DIABETES, ASTHMA, THYROID
}
