package com.hex.hms.service;

import com.hex.hms.dto.PatientDto;
import com.hex.hms.dto.PatientReportCountDto;
import com.hex.hms.model.Patient;
import com.hex.hms.repository.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    private final PatientRepository patientRepository;

    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    public Patient addPatient(PatientDto patientDto) {
        Patient patient = new Patient();
        patient.setName(patientDto.getName());
        patient.setCity(patientDto.getCity());
        patient.setIdProof(patientDto.getIdProof());

        return patientRepository.save(patient);
    }

  
//    public List<PatientReportCountDto> getAllPatientsWithReportCount() {
//        return patientRepository.fetchAllPatientsWithReportCount();
//    }
}
