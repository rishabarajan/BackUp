package com.hex.hms.repository;

import com.hex.hms.model.PatientMedicalIllness;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientMedicalIllnessRepository extends JpaRepository<PatientMedicalIllness, Integer> {
}
