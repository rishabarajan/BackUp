package com.hex.hms.dto;

import com.hex.hms.enums.IdProof;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class PatientDto {
	@NotNull
	@NotBlank
    private String name;
    private String city;
    private IdProof idProof;

    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public IdProof getIdProof() {
        return idProof;
    }
    public void setIdProof(IdProof idProof) {
        this.idProof = idProof;
    }
}
