package com.hex.hms.service;

import com.hex.hms.model.Patient;
import com.hex.hms.model.Report;
import com.hex.hms.repository.PatientRepository;
import com.hex.hms.repository.ReportRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportService {

    private final ReportRepository reportRepository;
    private final PatientRepository patientRepository;

    public ReportService(ReportRepository reportRepository, PatientRepository patientRepository) {
        this.reportRepository = reportRepository;
        this.patientRepository = patientRepository;
    }

    public Report addReport(Report report, int patientId) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found with id: " + patientId));

        report.setPatient(patient);
        return reportRepository.save(report);
    }
}
