package com.hex.hms.controller;

import com.hex.hms.dto.PatientDto;
import com.hex.hms.dto.PatientReportCountDto;
import com.hex.hms.model.Patient;
import com.hex.hms.service.PatientService;
import jakarta.validation.Valid;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/patient")
public class PatientController {

    @Autowired
    private PatientService patientService;
//    @GetMapping("/all")
//    public List<PatientReportCountDto> getAllPatients() {
//        return patientService.getAllPatientsWithReportCount();
//    }
    @PostMapping("/add")
    public ResponseEntity<Patient> addPatient(@Valid @RequestBody PatientDto dto) {
       
        return ResponseEntity.ok(patientService.addPatient(dto));
    }
}
