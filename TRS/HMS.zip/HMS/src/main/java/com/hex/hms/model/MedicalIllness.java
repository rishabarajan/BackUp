package com.hex.hms.model;

import com.hex.hms.enums.IllnessName;

import jakarta.persistence.*;

@Entity
public class MedicalIllness {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Enumerated(EnumType.STRING)
    private IllnessName illnessName;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public IllnessName getIllnessName() { return illnessName; }
    public void setIllnessName(IllnessName illnessName) { this.illnessName = illnessName; }
}
