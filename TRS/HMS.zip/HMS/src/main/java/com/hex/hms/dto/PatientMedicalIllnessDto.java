package com.hex.hms.dto;


import java.time.LocalDate;

public class PatientMedicalIllnessDto {
    private int patientId;
    private int medicalIllnessId;
    private LocalDate sinceWhenDate;

    
    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public int getMedicalIllnessId() {
        return medicalIllnessId;
    }

    public void setMedicalIllnessId(int medicalIllnessId) {
        this.medicalIllnessId = medicalIllnessId;
    }

    public LocalDate getSinceWhen() {
        return sinceWhenDate;
    }

    public void setSinceWhenDate(LocalDate sinceWhenDate) {
        this.sinceWhenDate = sinceWhenDate;
    }
}
