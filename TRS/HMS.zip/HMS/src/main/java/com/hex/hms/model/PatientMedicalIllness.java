package com.hex.hms.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class PatientMedicalIllness {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    private Patient patient;

    @ManyToOne
    private MedicalIllness medicalIllness;

    private LocalDate sinceWhen;

    public int getId() {
    	return id;
    	}
    
    
    public void setId(int id) { this.id = id; }

    public Patient getPatient() { return patient; }
    public void setPatient(Patient patient) { this.patient = patient; }

    public MedicalIllness getMedicalIllness() { return medicalIllness; }
    public void setMedicalIllness(MedicalIllness medicalIllness) { this.medicalIllness = medicalIllness; }

    public LocalDate getSinceWhen() { return sinceWhen; }
    public void setSinceWhen(LocalDate sinceWhen) { this.sinceWhen = sinceWhen; }
}
