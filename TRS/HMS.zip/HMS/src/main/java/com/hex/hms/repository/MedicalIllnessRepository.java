package com.hex.hms.repository;

import com.hex.hms.model.MedicalIllness;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MedicalIllnessRepository extends JpaRepository<MedicalIllness, Integer> {
}
