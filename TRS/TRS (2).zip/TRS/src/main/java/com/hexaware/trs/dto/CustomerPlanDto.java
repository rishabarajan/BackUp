package com.hexaware.trs.dto;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CustomerPlanDto {

    private int id;
    private String name;
    private String city;
    private List<PlanDto> listPlanDto;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public List<PlanDto> getListPlanDto() {
        return listPlanDto;
    }

    public void setListPlanDto(List<PlanDto> listPlanDto) {
        this.listPlanDto = listPlanDto;
    }
}