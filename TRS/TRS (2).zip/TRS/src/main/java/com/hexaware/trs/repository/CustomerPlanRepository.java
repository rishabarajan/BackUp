package com.hexaware.trs.repository;

import com.hexaware.trs.dto.CustomerPlanFlatDto;
import com.hexaware.trs.model.CustomerPlan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerPlanRepository extends JpaRepository<CustomerPlan,Integer> {

    @Query("""
            select new com.hexaware.trs.dto.CustomerPlanFlatDto(c.id,c.name,p.id,p.planName,p.price,cp.dateOfActivation)
            from Customer c LEFT JOIN CustomerPlan cp ON c = cp.customer
            LEFT JOIN Plan p ON cp.plan = p
            """)
    List<CustomerPlanFlatDto> getCustomerWithPlanDetails();
}