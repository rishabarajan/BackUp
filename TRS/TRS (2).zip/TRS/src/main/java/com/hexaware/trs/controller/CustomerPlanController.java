package com.hexaware.trs.controller;

import com.hexaware.trs.dto.CustomerPlanDto;
import com.hexaware.trs.model.Customer;
import com.hexaware.trs.model.CustomerPlan;
import com.hexaware.trs.model.Plan;
import com.hexaware.trs.service.CustomerPlanService;
import com.hexaware.trs.service.CustomerService;
import com.hexaware.trs.service.PlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer/plan")
public class CustomerPlanController {

    @Autowired
    private CustomerService customerService;
    @Autowired
    private PlanService planService;
    @Autowired
    private CustomerPlanService customerPlanService;

    @PostMapping("/add/{customerId}/{planId}")
    public CustomerPlan add(@PathVariable int customerId,
                            @PathVariable int planId){
        Customer customer = customerService.getById(customerId);
        
        Plan plan = planService.getById(planId);

        return customerPlanService.add(customer,plan);

    }

    @GetMapping("/all")
    public List<?> getCustomerWithPlanDetails(){
        return customerPlanService.getCustomerWithPlanDetails();
    }
}