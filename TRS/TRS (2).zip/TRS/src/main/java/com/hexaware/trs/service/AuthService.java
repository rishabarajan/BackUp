package com.hexaware.trs.service;

import com.hexaware.trs.model.User;
import com.hexaware.trs.repository.AuthRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final AuthRepository authRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthService(AuthRepository authRepository, PasswordEncoder passwordEncoder) {
        this.authRepository = authRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public User signUp(User user) {
        //encode the password
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return authRepository.save(user);
    }

}