package com.hexaware.trs.dto;

import org.springframework.stereotype.Component;

@Component
public class TicketDto {
    private String subject;
    private String issue;
    private String priority;

    public String getSubject() {
        return subject;
    }

    public String getIssue() {
        return issue;
    }

    public String getPriority() {
        return priority;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }
}