package com.hexaware.trs.service;

import com.hexaware.trs.model.Plan;
import com.hexaware.trs.repository.PlanRepository;
import org.springframework.stereotype.Service;

@Service
public class PlanService {
    private final PlanRepository planRepository;

    public PlanService(PlanRepository planRepository) {
        this.planRepository = planRepository;
    }

    public Plan add(Plan plan) {
        return planRepository.save(plan);
    }

    public Plan getById(int planId) {
        return planRepository
                .findById(planId)
                .orElseThrow(()-> new RuntimeException("Plan Id Invalid"));
    }
}