package com.hexaware.trs.enums;

public enum TicketPriority {
LOW,HIGH,MEDIUM
}
