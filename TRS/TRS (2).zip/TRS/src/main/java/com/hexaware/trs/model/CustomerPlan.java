package com.hexaware.trs.model;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "customer_plan")
public class CustomerPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    /* Metadata */
    @Column(name = "date_of_activation")
    private LocalDate dateOfActivation;
    @ManyToOne
    private Customer customer;
    @ManyToOne
    private Plan plan;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getDateOfActivation() {
        return dateOfActivation;
    }

    public void setDateOfActivation(LocalDate dateOfActivation) {
        this.dateOfActivation = dateOfActivation;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Plan getPlan() {
        return plan;
    }

    public void setPlan(Plan plan) {
        this.plan = plan;
    }
}