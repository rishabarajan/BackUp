package com.hexaware.trs.controller;

import com.hexaware.trs.model.Customer;
import com.hexaware.trs.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping("/add")
    public Customer postCustomer(@RequestBody Customer customer){
        return customerService.add(customer);
    }

    @GetMapping("/info")
    public List<?> getCustomerInfo(@RequestParam(required = false, defaultValue = "0") int page,
                                   @RequestParam(required = false, defaultValue = "2") int size){
        return customerService.getInfo(page,size);
    }
}