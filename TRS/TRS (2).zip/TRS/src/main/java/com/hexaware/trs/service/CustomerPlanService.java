package com.hexaware.trs.service;

import com.hexaware.trs.dto.CustomerPlanDto;
import com.hexaware.trs.dto.CustomerPlanFlatDto;
import com.hexaware.trs.dto.PlanDto;
import com.hexaware.trs.model.Customer;
import com.hexaware.trs.model.CustomerPlan;
import com.hexaware.trs.model.Plan;
import com.hexaware.trs.repository.CustomerPlanRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class CustomerPlanService {

    private final CustomerPlanRepository customerPlanRepository;

    public CustomerPlanService(CustomerPlanRepository customerPlanRepository) {
        this.customerPlanRepository = customerPlanRepository;
    }

    public CustomerPlan add(Customer customer, Plan plan) {
        CustomerPlan customerPlan = new CustomerPlan();
        customerPlan.setDateOfActivation(LocalDate.now());
        customerPlan.setCustomer(customer);
        customerPlan.setPlan(plan);
        return customerPlanRepository.save(customerPlan);
    }

    public List<?> getCustomerWithPlanDetails() {

        return customerPlanRepository.getCustomerWithPlanDetails();

//        CustomerPlanDto dto = new CustomerPlanDto();
//        dto.setName("dummy");
//        dto.setId(1);
//        dto.setCity("dummy");
//
//        PlanDto dto1 = new PlanDto();
//        dto1.setId(1);
//        dto1.setName("dummy");
//        dto1.setPrice(1200);
//        PlanDto dto2 = new PlanDto();
//        dto2.setId(2);
//        dto2.setName("dummy2");
//        dto2.setPrice(1300);
//
//        List<PlanDto> listPlanDto = List.of(dto1,dto2);
//        dto.setListPlanDto(listPlanDto);
//
//        List<CustomerPlanDto> list = List.of(dto);
//        return list;

    }
}