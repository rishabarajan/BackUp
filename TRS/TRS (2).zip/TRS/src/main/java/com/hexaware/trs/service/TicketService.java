package com.hexaware.trs.service;

import com.hexaware.trs.dto.TicketDto;
import com.hexaware.trs.enums.TicketPriority;
import com.hexaware.trs.enums.TicketStatus;
import com.hexaware.trs.model.Customer;
import com.hexaware.trs.model.Ticket;
import com.hexaware.trs.repository.CustomerRepository;
import com.hexaware.trs.repository.TicketRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketService {

    private final TicketRepository ticketRepository;
    private final CustomerRepository customerRepository;

    public TicketService(TicketRepository ticketRepository, CustomerRepository customerRepository) {
        this.ticketRepository = ticketRepository;
        this.customerRepository = customerRepository;
    }

    public Ticket add(Ticket ticket) {
        return ticketRepository.save(ticket);
    }

    public Ticket add(int customerId, TicketDto ticketDto) {
           TicketPriority priority =  TicketPriority.valueOf(ticketDto.getPriority());
            Customer customer =  customerRepository
                                    .findById(customerId)
                                    .orElseThrow(()->new RuntimeException("Customer Id Invalid"));

            Ticket ticket = new Ticket();
            ticket.setSubject(ticketDto.getSubject());
            ticket.setIssue(ticketDto.getIssue());
            ticket.setCustomer(customer);
            ticket.setTicketPriority(priority);
            ticket.setTicketStatus(TicketStatus.OPEN);
            return ticketRepository.save(ticket);
    }
}