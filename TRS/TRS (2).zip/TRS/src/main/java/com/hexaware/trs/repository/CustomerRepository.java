package com.hexaware.trs.repository;

import com.hexaware.trs.dto.CustomerDto;
import com.hexaware.trs.enums.TicketPriority;
import com.hexaware.trs.model.Customer;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Integer> {

    @Query("""
            select new com.hexaware.trs.dto.CustomerDto(c.id,c.name,c.city,count(t.id),
            sum(case when t.ticketPriority = :priority then 1 else 0 end))
            from Customer c LEFT JOIN Ticket t ON c = t.customer
            group by c.id, c.name, c.city
            """)
    List<CustomerDto> getCustomerInfoWithTicketCounts(
            @Param("priority") TicketPriority priority,
            Pageable pageable
    );
}
/*
select count(t.id) as num_tickets , c.id,c.name,c.city
    from customer c LEFT JOIN tickets t ON c.id = t.customer_id
    group by c.id,c.name,c.city;
* */

//    @Query("select new com.hex.trs.dto.CustomerDto("
//            + " c.id, "
//            + " c.name, "
//            + " c.city, "
//            + " count(t.id), "
//            + " coalesce(sum(case when t.ticketPriority = :priority then 1 else 0), 0) "
//            + " ) " // Correct position for the constructor's closing parenthesis
//            + " from Customer c LEFT JOIN Ticket t ON c = t.customer "
//            + " group by c.id, c.name, c.city")