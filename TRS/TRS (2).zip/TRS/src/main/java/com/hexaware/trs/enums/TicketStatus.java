package com.hexaware.trs.enums;

public enum TicketStatus {
OPEN,IN_PROCESS,CLOSED
}
