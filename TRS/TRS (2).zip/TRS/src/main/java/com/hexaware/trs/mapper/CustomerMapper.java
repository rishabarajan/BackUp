package com.hexaware.trs.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.hexaware.trs.dto.CustomerDto;
import com.hexaware.trs.model.Customer;
@Component
public class CustomerMapper {

    public CustomerDto fromEntityToDto(Customer customer){ //single object conversion
        CustomerDto dto = new CustomerDto(
                customer.getId(),
                customer.getName(),
                customer.getCity()
        );
        return dto;
    }

    public List<CustomerDto> fromEntityListToDtoList(List<Customer> list){ //list to list conversion
        List<CustomerDto> listDto = new ArrayList<>();
        list.forEach(c->{
            CustomerDto dto = fromEntityToDto(c);
            listDto.add(dto);
        });
        return listDto;
    }
}