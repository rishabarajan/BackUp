package com.hexaware.trs.controller;

import com.hexaware.trs.dto.TicketDto;
import com.hexaware.trs.model.Ticket;
import com.hexaware.trs.service.TicketService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ticket")
public class TicketController {

    @Autowired
    private TicketService ticketService;

    @PostMapping("/add/{customerId}")
    public Ticket postTicket(@PathVariable int customerId,
                                        @Valid @RequestBody TicketDto ticketDto){
            return ticketService.add(customerId, ticketDto);
    }


}