package com.hex.pay.controller;

import com.hex.pay.dto.PaymentDto;
import com.hex.pay.model.Payment;
import com.hex.pay.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/add")
    public Payment postPayment(@RequestBody Payment payment) {
        return paymentService.add(payment);
    }

    @PostMapping("/add/{customerId}")
    public Payment postPaymentForCustomer(@PathVariable int customerId,
                                          @Valid @RequestBody PaymentDto paymentDto) {
        return paymentService.add(customerId, paymentDto);
    }
}
