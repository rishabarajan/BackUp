
package com.hex.pay.dto;

import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public class PaymentDto {

    @NotNull
    private BigDecimal amount;

    @NotNull
    private String paymentMode;

   
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getPaymentMode() { return paymentMode; }
    public void setPaymentMode(String paymentMode) { this.paymentMode = paymentMode; }
}
