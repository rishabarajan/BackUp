package com.hex.pay.controller;

import com.hex.pay.dto.CustomerDto;
import com.hex.pay.model.Customer;
import com.hex.pay.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

   
    @PostMapping("/add")
    public Customer postCustomer(@Valid @RequestBody CustomerDto customerDto) {
        return customerService.add(customerDto);
    }
}
