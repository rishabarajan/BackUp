package com.hex.pay.dto;

import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public class AccountDto {

    @NotNull
    private String type; 

    @NotNull
    private BigDecimal balance;
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }
}
