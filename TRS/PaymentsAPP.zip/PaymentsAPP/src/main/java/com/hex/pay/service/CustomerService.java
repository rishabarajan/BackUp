package com.hex.pay.service;

import com.hex.pay.dto.AccountDto;
import com.hex.pay.dto.CustomerDto;
import com.hex.pay.enums.AccountType;
import com.hex.pay.model.Account;
import com.hex.pay.model.Customer;
import com.hex.pay.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public Customer add(Customer customer) {
        return customerRepository.save(customer);
    }

    public Customer add(CustomerDto customerDto) {
        Customer customer = new Customer();
        customer.setName(customerDto.getName());
        customer.setCity(customerDto.getCity());

        AccountDto accDto = customerDto.getAccount();
        Account account = new Account();
        account.setType(AccountType.valueOf(accDto.getType()));
        account.setBalance(accDto.getBalance() != null ? accDto.getBalance() : BigDecimal.ZERO);

        customer.setAccount(account);

        return customerRepository.save(customer);
    }
}
