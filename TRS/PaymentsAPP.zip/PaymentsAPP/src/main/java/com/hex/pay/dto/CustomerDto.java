package com.hex.pay.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class CustomerDto {

    @NotBlank
    private String name;

    private String city;

    @NotNull
    private AccountDto account;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public AccountDto getAccount() { return account; }
    public void setAccount(AccountDto account) { this.account = account; }
}
