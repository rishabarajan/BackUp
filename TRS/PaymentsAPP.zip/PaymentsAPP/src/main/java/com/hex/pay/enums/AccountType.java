
package com.hex.pay.enums;

public enum AccountType {
    SAVINGS,
    CURRENT
}
