package com.hex.pay.service;

import com.hex.pay.dto.PaymentDto;
import com.hex.pay.enums.PaymentMode;
import com.hex.pay.model.Account;
import com.hex.pay.model.Customer;
import com.hex.pay.model.Payment;
import com.hex.pay.repository.CustomerRepository;
import com.hex.pay.repository.PaymentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final CustomerRepository customerRepository;

    public PaymentService(PaymentRepository paymentRepository, CustomerRepository customerRepository) {
        this.paymentRepository = paymentRepository;
        this.customerRepository = customerRepository;
    }

    public Payment add(Payment payment) {
        return paymentRepository.save(payment);
    }

    @Transactional
    public Payment add(int customerId, PaymentDto paymentDto) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer Id Invalid"));

        Payment payment = new Payment();
        payment.setAmount(paymentDto.getAmount());
        payment.setPaymentMode(PaymentMode.valueOf(paymentDto.getPaymentMode()));

        payment.setCustomer(customer);

        Account account = customer.getAccount();
        if (account == null) {
            throw new RuntimeException("Customer has no associated account");
        }

        BigDecimal current = account.getBalance() == null ? BigDecimal.ZERO : account.getBalance();
        BigDecimal amount = paymentDto.getAmount();

        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("Invalid payment amount");
        }

        if (current.compareTo(amount) < 0) {
            throw new RuntimeException("Insufficient balance");
        }

        account.setBalance(current.subtract(amount));

       customerRepository.save(customer);

        return paymentRepository.save(payment);
    }
}
