package com.hex.pay.enums;

public enum PaymentMode {
    UPI,
    NEFT
}