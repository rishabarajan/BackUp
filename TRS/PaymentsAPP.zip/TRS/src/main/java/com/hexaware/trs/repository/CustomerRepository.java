package com.hexaware.trs.repository;

import com.hexaware.trs.dto.CustomerDto;
import com.hexaware.trs.model.Customer;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
@Repository
public interface CustomerRepository extends JpaRepository<Customer,Integer> {

    @Query("select new com.hexaware.trs.dto.CustomerDto(c.id,c.name,c.city,count(t.id)) " +
            " from Customer c LEFT JOIN Ticket t ON c = t.customer " +
            " group by c.id,c.name,c.city")
    List<CustomerDto> getCustomerInfoWithTicketCounts();
}