package com.hexaware.trs.controller;

import com.hexaware.trs.model.Customer;
import com.hexaware.trs.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping("/add")
    public Customer postCustomer(@RequestBody Customer customer){
        return customerService.add(customer);
    }

    @GetMapping("/info")
    public List<?> getCustomerInfo(){
        return customerService.getInfo();
    }
}