package com.hexaware.trs.service;

import com.hexaware.trs.dto.CustomerDto;
import com.hexaware.trs.mapper.CustomerMapper;
import com.hexaware.trs.model.Customer;
import com.hexaware.trs.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;
    private final CustomerMapper customerMapper;

    public CustomerService(CustomerRepository customerRepository,
                           CustomerMapper customerMapper) {
        this.customerRepository = customerRepository;
        this.customerMapper = customerMapper;
    }

    public Customer add(Customer customer) {
        return customerRepository.save(customer);
    }

    public List<?> getInfo() {

        List<CustomerDto> list = customerRepository.getCustomerInfoWithTicketCounts();
//        List<CustomerDto> listDto =  customerMapper.fromEntityListToDtoList(list);
        return list;
    }
}